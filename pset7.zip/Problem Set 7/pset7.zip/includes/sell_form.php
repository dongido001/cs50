<div>
    <form action="/sell.php" method="POST" >
       <div>
           <select>
           
          <option value=" <?= 1 ?> "> </option>
          
          </select>
       </div> 
       <div>
           <input class="btn btn-form" type="submit" name="SELL"/>
       </div>
     </form>
</div>
