<?php
$lo=cript("dongido");
echo $lo;

?>
