<?php
/*Pset7
*sell.php
*By ONWUKA GIDEON O
*dongidomed@gmail.com
*2348059794251
*/
//include config files
require("../includes/config.php");

//gets number of shares a user have...
if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $arr=[];
//query to get share info  from the portfolio table...
   $roww=query("SELECT symbol,share FROM portfolio WHERE id=?",$_SESSION["id"]);
//render templates...
   foreach( $roww as $ro)
   {
  $stock=lookup($ro["symbol"]);
  $arr []=[ "symbol"=>$ro["symbol"],"price"=>$stock["price"] ];
   }
   render("sell_form.php",["arr"=>$arr,"title"=>"SELL"]);
}
  else //request method is POST
{
//makes sure users have stock to sell....
if(count($roww)>=1)
  {
   //gets user total money remaining...
   $mony=query("SELECT cash FROM users WHERE id=?",$_SESSION["id"]);
  if($mony!==false)
     {
       $cash_remaining=$money[0]["cash"];
     $Psold=$stock["price"];
//updates users cash...
  $update=query("UPDATE users SET cash=$cash_remaining+$Psold WHERE id=?",$_SESSION["id"]);
//updates user history...

$r=$ro["symbol"];
$n=NOW();
$sold="sold";
$ses=$_SESSION["id"];
  $history=query("INSERT INTO history  ($ses,date,time,bot_or_sold,symbol,number,price) VALUES ($n,$n,$sold,$r,1,$Psold)");
    
//delete the share sold...
//if number share is  >1

$no_share=$roww["share"];
$cur_share; 
  if($no_share > 1)
  {
 $cur_share=$no_share-1;

$s=$_SESSION["id"];
$t=$roww["symbol"];
//reduce the number of shell in the database...
 $del=query("UPDATE portfolio SET share=$cur_share WHERE id=$s");
  }
else {
$s=$_SESSION["id"];
$t=$roww["symbol"];
  $delete=query("DELETE FROM portfolio WHERE id=$s AND symbol=$t");
     if($delete===false)
        {
        apologize("database error...");
        } 
  } 
    }
  }
 else
     {
   apologize("You dont have any share...");
     }
}

?>









