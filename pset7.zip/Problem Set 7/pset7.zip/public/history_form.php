<div>
 <?php $count=1; ?>
    <?php foreach($hold as $row):?>
     <tr style="padding:3px;">
       <td><?= $count; ?></td>
       <td><?= $row["symbol"]; ?></td>
       <td><?= $row["bought_or_sold"]; ?></td>
       <td><?= $row["price"]; ?></td>
       <td><?= $row["number"]; ?></td>
       <td><?= $row["date"]; ?></td>
     </tr>
 <?php $count++; ?>
   <?php endforeach;?>
</div>
