
<form method="POST" action="/buy.php">
   <div>
     <input class="" type="text" name="symbol" placeholder="symbol" />
   <div>
   <div>
     <input class="" type="text" name="shares" placeholder="shares" />
   <div>
   <div>
     <input class ="btn btn-form" type="submit" value="BUY" />
   <div>
   
</form>
