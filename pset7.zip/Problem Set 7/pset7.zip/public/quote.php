<?php
/*quote.php
*it serves as a contoller...
*By Onwuka Gideon O
*dongidomed@gmail.com
*/
//includes config files...
   require("../includes/config.php");

    //if method is via quote...
   if($_SERVER['REQUEST_METHOD']=="GET")
     {
     //render form...
    render("quote_form.php",["title="=>"quote form..."]);
     }
   else {
     //else take action...

  if($stock=lookup($_POST['symbol']))
    {
    render("quote_display.php",["title"=>"Your Quote..."]);
    }
  else {
    apologize("Invalid Stock inputed...");
    }
 }
?>






