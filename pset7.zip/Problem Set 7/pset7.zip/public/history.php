<?php
/*cs50 2015 pset7 
*history.php
*ONWUKA GIDEON O
*shows history to user(Az in activities of the user)...
*dongidomed@gmail.com
*+2348059794251
*/

   //config file
require("../includes/config.php");
  
 //make an array...
$arr=[];

//query the history table...
$query=query("SELECT date,time,bot_or_sold,symbol,number,price FROM history WHERE id=? ORDER BY time",$_SESSION["id"]);

  if($query!==false)
{
   foreach($query as $ro)
     {
   $arr []=[ "date"=>$ro["date"],"bought_or_sold"=>$ro["bot_or_sold"],"symbol"=>$ro["symbol"],"number"=>$ro["number"],"price"=>$ro["price"],"time"=>$ro["time"] ];
     } 
if(count($query)<1)
   {
     echo "<div>";
             echo "\nyou don have any history recorded...\n";
     echo "</div>";
   } 
  else {
      render("history_form.php",["arr"=>$arr,"title"=>"HISTORY"]);        
      }
 //close of table tag </table>...
 if(count($query)>=1)
    {
     echo "</table>";
    }

}
?>












