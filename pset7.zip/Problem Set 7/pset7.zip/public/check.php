dhhdhh
<?php 
include ("../includes/config.php");
$lo=crypt("dongido");
echo $lo;

?>
