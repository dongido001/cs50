<?php

    // configuration
    require("../includes/config.php"); 
//menu links...


    // render portfolio

    $positions=[];
//query to get share info  from the portfolio table...
   $rows=query("SELECT symbol,share FROM portfolio WHERE id=?",$_SESSION["id"]);
   if($rows!==false)
      {
        foreach($rows as $row)
          {
         $stock=lookup($row["symbol"]);
            if($stock!==false)
               {
               $positions[]=[
                  "name"=>$stock["name"],
                  "price"=>$stock["price"],
                  "shares"=>$row["shares"],
                  "symbol"=>$row["symbol"],
                            ];
               }
          }
      }

//get users current cash...

$rowss=query("SELECT cash FROM users WHERE id=?",$_SESSION['id']);
if(count($rowss)==1)
{
$cash_left=$rowss[0]['cash'];
}
else
   {/*just for debugging sake...*/
apologize("something went wrong!");
   } 
   
    render("portfolio.php", ["positions"=>$positions,"cash_left"=>$cash_left,"title" => "Portfolio"]);

?>





