<?php
/*pset7 
*changepd.php
*ONWUKA GIDEON O
*dongidomed@gmail.com
*+2348059794251
*/
//require config files...
   require("../includes/config.php");
   if($_SERVER["REQUEST_METHOD"]!="POST")
    {
//includes a form...
  render("changepd_form1.php",["title"=>"change password"]);
   }
  else {
 //mekes sure user is complying...
     if(empty($_POST["new1"]) || empty($_POST["old"]) || empty ($_POST["new2"]))
      {
     apologize("All field must be filled\n please try again...");
      }
//check if user is typing the same new password...
 if($_POST["new1"]!=$_POST["new2"])
    {
apologize("new password do no match...");
    }
   //check if old password is correct...
$q=query("SELECT hash FROM users WHERE id =?",$_SESSION["id"]);
   if($q===false)
     {
echo "query failed...";
     }
    else {

       if($q[0]["hash"]==crypt($_POST["old"],$q[0]["hash"]))
          {
   //change password...
$update=query("UPDATE users SET hash=? WHERE id=?",crypt($_POST["new2"]),$_SESSION["id"]);
//for debuging...
   echo "You have sucessfully changed your password..."; 
echo '<a href="/portfolio.php">portfolio</a>';
          }
else{  echo "password do no match"; }

         }
  }
?>






