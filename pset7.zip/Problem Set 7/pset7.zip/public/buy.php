<?php
/*cs50 pset7
*buy.php
*Onwuka Gideon O
*dongidomed@gmail.com
*+2348059794251
*...
*....
*/
//include config files...
require("../includes/config.php");

if($_SERVER["REQUEST_METHOD"]=="GET")
   {
 render("buy_form.php",["title"=>"buy share"]);

   }
else //method is POST
  {   
   $symbol=strtoupper($_POST["symbol"]);
   $number=$_POST["shares"];
//Now makes sure user is cooperating...
  //makes sure that symbol inputed by user is valid...
if(lookup($symbol)==false)
   {
apologize("sorry symbol not found...");
   } 
if(empty($number) || empty($symbol) )
   {
apologize("YOU MUST FILL OUT BOTH FORM\n pls retry...");
   }
if(!preg_match("/^\d+$/",$number) || $number <= 0 || !is_int($number) )
   {
apologize("only number greater than 0 is allowed in this field...");
   }
//checks if user have enough cash for the share he/she wants to buy...
$stock=lookup($symbol);
  $price=$stock["price"]*$number;
//gets user cash
$query=query("SELECT cash FROM users WHERE id=? ",$_SESSION["id"]);
   //does the check to know if user have enough cash...
  if($price > $query["cash"])
     {
  aplogize("YOU DONT HAVE ENOUGH CASH LEFT\n pls fund your account...");
     }
   //if everything goes successfully...
$f=$_SESSION["id"];
//updates user accounts according to number of share bought.
 query("INSERT INTO portfolio(id,symbol,share) VALUES ($f,$symbol) ON DUPLICATE KEY UPDATE share=share+$number WHERE id=?",$_SESSION["id"]);  
  //updates user history...
$f=$_SESSION["id"];
$symbo=$ro["symbol"];
$n=NOW();
$bot="bought";
 query("INSERT INTO history(id,date,time,bot_or_sold,symbol,number,price) VALUES($f,$n,$n,$bot,$symbo,$number,$price)");
    if(query===false)
     {
echo "query failed...";
      }
 //redirect to portfolio
  redirect("/");
  }

?>











