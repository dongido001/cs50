<?php
   //configuration

 require("../includes/config.php");


  if($_SERVER["REQUEST_METHOD"]=="POST")
      {
      print "report...";
        //declaring my variables...
     $user=$_POST['username'];
     $pass=$_POST['password'];
     $comf=$_POST['comfirmation'];
//makes sure everything was filled up...
      if(empty($user) || empty($pass) || empty($comf))
        {
       apologize("Error: One or more fields is/are empty!, please cross check again...");
        }
      else if($pass!=$comf)
         {
        apologize("Error: password does not match,please retry... ");
         }
      else {
      //insert data into database...
  $result=query("INSERT INTO users (username,hash,cash) VALUES (?,?,10000.0000)",$user,crypt($pass));
      } 
      //checks if insertion was successfull...
    if($result===false) {
     apologize("Error: we think username supplied already exits, please try again...");
        }

    $rows=query("SELECT LAST_INSERT_ID() AS id");
         $id=$rows[0]['id'];
      //logs user in and assign a session to him/her...
            $_SESSION["id"] = $id;
                // redirect to portfolio
                redirect("/");
        

     }
     else 
     {
     //if user reaches page via get(as by clicking a link or via redirect)
 
        //else render form

      render("register_form.php",["title"=>"Register"]);
     }
?>  



