
<form method="POST" action="/buy.php">
   <div>
     <input class="" type="text" name="symbol" placeholder="symbol" />
   
   <div> <br>
   <div>
     <input class="" type="text" name="shares" placeholder="shares" />
   <div>
   <div> <br>
     <input class ="btn btn-form" type="submit" value="BUY" />
   <div>
   
</form>
