<div>
You are about to change your password...
</div>
<div class="form-control">
   <form  action="/changepd.php" method ="POST">
       
       

   </form>
</div>
