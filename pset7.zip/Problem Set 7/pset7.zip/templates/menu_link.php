<div style="width:100%;border:1px solid green;">
    <a style="padding:4px;text-decoration:none;" href="/buy.php">BUY</a>
  
    <a style="padding:4px;text-decoration:none;" href="/logout.php">LOGOUT</a>
    <a style="padding:4px;text-decoration:none;" href="/quote.php">QUOTE</a>
    <a style="padding:4px;text-decoration:none;" href="/sell.php">SELL</a>
    <a style="padding:4px;text-decoration:none;" href="/history.php">HISTORY</a>
</div>
