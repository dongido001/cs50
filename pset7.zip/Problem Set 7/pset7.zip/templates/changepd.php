<?php
/*pset7 
*changepd.php
*ONWUKA GIDEON O
*dongidomed@gmail.com
*+2348059794251
*/
//require config files...
   require("../includes/config.php");
  //includes a form...
  render("changepd_form1.php",["title"=>"change password"]);
if($_SERVER["REQUEST_METHOD"]=="POST")
   {
     //check if password is correct...
$query=query("SELECT hash FROM users where id=SESSION['id']");
   if($query!==false)
        {
    //confirm old password...
          if($query["hash"]==$_POST["old"])
            {
           redirect("/changepd.php");
          
             }
       } 
  }
else
  {
   render("../changepd_form2.php");

  }

?>
