<div style="width:100%;border:1px solid green;">
    <a style="padding:4px;text-decoration:none;" href="/buy.php">BUY</a>
  
    <a style="padding:4px;text-decoration:none;" href="/logout.php">LOGOUT</a>
    <a style="padding:4px;text-decoration:none;" href="/quote.php">QUOTE</a>
    <a style="padding:4px;text-decoration:none;" href="/sell.php">SELL</a>
    <a style="padding:4px;text-decoration:none;" href="/history.php">HISTORY</a>
        <a style="padding:4px;text-decoration:none;" href="/changepd.php">CHANGE PASSWORD</a>
</div>
<hr style="margin-left:0px">
   <table style="border-collapse:collapse;width:100%;border:1px solid green;background:gray;cell-spacing:2px;spacing:2px;margin-top:0px;margin-left:0px">
    <thead style="background-color:green;color:white;font-size:bold;padding:3px;width:100%;border:1px solid black;">
    
     <td>Symbol</td>
     <td>Name</td>
     <td>Shares</td>
     <td>Price</td>
     <td>Total</td>
    </thead>
<?php $no=1;?>
 <?php foreach($positions as $posi):?>
  <tr>
        <td><?php $posi["symbol"] ?></td>
        <td><?php $posi["name"] ?></td>
        <td><?php $posi["shares"] ?></td>
        <td><?php $posi["price"] ?> </td>
<?php $total=$posi["price"]*$posi["shares"]?>
        <td><?= $total ?><td/>
        <td><?= $no++; ?><td/>
  </tr>
<?php endforeach;?>
   </table> 
<hr>
      <table style="background-color:green;color:white;font-size:bold;padding:3px;width:100%;border:1px solid black;">
       <td style="margin-left:0px;width;padding-left:0px;float:left">Cash</td><td style="margin-right:0px;padding-right:0px;float:right"><?= "$".number_format($cash_left,2); ?></td>
   </table>
<div>
    <a href="logout.php">Log Out</a>
</div>
