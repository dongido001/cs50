<div>
    <form action="/sell.php" method="POST" >
       <div>
           <select>
          <?php foreach($arr as $array):?> 
          <option value=' <?= $array["symbol"]; ?> '><?=$array["symbol"]; ?></option>
          <?php endforeach;?>
          </select>
       </div> 
          <br>
       <div>
           <input class="btn btn-form" type="submit" name="SELL"/>
       </div>
     </form>
</div>
<?php
var_dump($arr);
?>
