<div>
You are about to change your password...
</div>
<div >
   <form  action="/changepd.php" method ="POST">
     <div class="form-control">  
        <input type="text" placeholder="old password" name="old" />
     </div>
   
 <input type="text" placeholder="new password" name="new1" />

        <div class="form-control">
        <input type="text" placeholder="comfirm password" name="new2" />
        </div>
        <div class="btn btn-control">
        <input type="submit" value="CHANGE !" />
       </div>
       
   </form>
</div>
