<div> 
   <table style="width:100%;color:white;">
       <tr style="width:100%;border:1px solid green;background:green;">
    <td>S/N</td>
    <td>DATE/TIME</td>
    <td>TRANSACTION</td>
    <td>SYMBOL</td>
    <td>NUMBER</td>
    <td>PRICE</td>
       </tr>
<?php $count=1; ?>
<?php foreach($arr as $arrt): ?>
   <tr style="width:100%;border:1px solid green;background:grey;">
      <td><?= $count ?> </td>
      <td><?= $arrt["date"] ?> /<?= $arrt["time"] ?> </td>
      <td><?= $arrt["bought_or_sold"]?> </td>
      <td><?= $arrt["symbol"]?> </td>
      <td><?= $arrt["number"]?> </td>
      <td><?= $arrt["price"]?> </td>
 </tr>
<?php $count++; ?>
<?php endforeach;  ?>
   </table>
</div>
