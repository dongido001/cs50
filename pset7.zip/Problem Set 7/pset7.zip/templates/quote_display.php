
<hr style="width:100%;margin:2px;">
<table style="border:1px solid green;margin:3px;background:0xfefefe;" >
    <tr>
     <td>
       Your quotes are as below...
     </td>
    </tr>
   <tr>
<td>Symbol</td><td>Name</td><td>Price</td>
   </tr>
  <tr>
   <td><?= $stock['symbol'];?></td><td><?= $stock['name'];?></td><td><?= number_format($stock["price"],2);?></td>
  </tr>
</table>














