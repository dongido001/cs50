<fieldset>

      <form method="POST" action="/quote.php">
<div class="form-group">
          <input autofocus class="form-control" type="text" name="symbol" placeholder="quote_symbol"/>
</div>
 <div class="form-group">
<input class="btn btn-default" type="submit" value="submit" name="quote_submit"/>
 </div>              
      </form>
</fieldset>
