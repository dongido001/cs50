/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <cs50.h>
int start=0;
int pad2=0;
typedef uint8_t  BYTE;

 typedef struct
    {
      BYTE size[512];
    }BLOCK;

char  str[9]="000.jpg";
  FILE* inptr;
  FILE* outptr;
  int d=0;
//  str="000.jpg";
int main(int argc, char* argv[])
{
    // Recovers Image
/*
    if(argc!=2)
    {
    printf("Usage :./recover file.raw\n");
    return 1;
    }
*/
char* file=argv[1];
inptr=fopen(file,"r");
outptr=fopen(str,"w");
// checks for error in opening file...
   if(inptr==NULL)
     {
     printf("File %s could not be opened...\n",file);
     return 2;
     fclose(inptr);
     }
if(outptr==NULL)
{
fclose(outptr);
return 3;
}
//read file 512 byte...
 BLOCK check;

while(!feof(inptr))
   {
fread(&check,sizeof(BLOCK),1,inptr);
if ((check.size[0]==0xff  && check.size[1]==0xd8 && check.size[2]== 0xff && check.size[3]==0xe0) || (check.size[0]==0xff  && check.size[1]==0xd8 && check.size[2]== 0xff && check.size[3]==0xe1))
   {
  start=start+1;
   if(start==2 || start==1)
   {
   // close file and open a new file...
        if(start==2)
        {
        d=d+1;
        fclose(outptr);     
       
         sprintf(str,"%03d.jpg",d);
        fopen(str,"w");
        start=1;
        }
   }
 }
 //determine when to start and close jpg file...
  if(start>0)
  {
  if(check.size !=NULL)
      {
      fwrite(&check,sizeof(BLOCK),1,outptr);
      }  
  }
  pad2=512;
 }
//  closes all file...
fclose(inptr);
fclose(outptr);
return 0;
}
