#include <cs50.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
   
 int main()
 {
//bubble sort ...
//sorts in decending order...
int arr[6]={4,1,6,1,2,0};
   for(int i=0;i<=5;i++)
    {
printf("%d+",arr[i]);
    }
printf("\n");


bool not_sorted=false;
   do
    {
      not_sorted=false;
         for(int i=0;i<5;i++)
           {
        if(arr[i]>arr[i+1])
         {
           int temp=arr[i];
           arr[i]=arr[i+1];
           arr[i+1]=temp;
             not_sorted=true;        
         }
           }
    }
while(not_sorted==true);

   for(int i=0;i<=5;i++)
    {
printf("%d+",arr[i]);
    }
printf("\n");

return 0;
 }






