
#include <stdbool.h>
#include <ctype.h> 
#include "dictionary.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/*
* Returns true if word is in dictionary else false.
*/
bool check(const char *word)
{  
//first of all convert the text to lower...
char hold_str[LENGTH+1];
  //gets lent of text input
int lent=strlen(word);
   for(int i=0;i<lent;i++)
       {
       char c=word[i];
       hold_str[i]=tolower(c);
       }   
 //indicates the end of t string...
 hold_str[lent]='\0';
//  int lenght=strlen(hold_string);
//gets array index...
int indexx=hash_f(hold_str);
BUCKET * temp=NULL;
temp=buckets[indexx];
//does the real searching...
   if(temp==NULL)
       {
       return false;
       }
//else search through the linked list...
   while(temp)
      {
         if(strcmp(temp->word,hold_str)==0)
            {
       //i found it!
            return true;
            }
      temp=temp->next;
      }
return false;
}

/*
* Loads dictionary into memory. Returns true if successful else false.
*/
bool load(const char *dictionary)
{
//TODO
//loads dictionary
   //opens the file...
FILE *fp=NULL;
fp=fopen(dictionary,"r");
   //if file opening fails, close me...
if(fp==NULL)
    {
    return 1;
    }
//variables that holds scaned string...

    //while end of file file is not reached...
  while(!feof(fp))
       {
       char temp[LENGTH+1];
       fscanf(fp,"%s\n",temp);
 //crates a new node
 BUCKET * new_bucket=NULL;
       new_bucket=malloc(sizeof(BUCKET));
       if(new_bucket==NULL)
          {
          printf("failed to create memory for storage...:");
          return 3;
          }
   //copies string from temp to new_bucket->word
       strcpy(new_bucket->word,temp);
       new_bucket->next=NULL;
         size_y++;
//gets word index,so that to know to include it in the array...
    int b_index;
  b_index=hash_f(temp);
//starts loading words to memory...
       if(buckets[b_index]==NULL)
          {
          buckets[b_index]=new_bucket;
          buckets[b_index]->next=NULL;
          }
       else if(buckets[b_index]->next==NULL)
          {
          buckets[b_index]->next=new_bucket;
          }
       else
           {
           new_bucket->next=buckets[b_index]->next;
           buckets[b_index]->next=new_bucket;
           }
       }
fclose(fp);
return true;
}
/*
* Returns number of words in dictionary if loaded else 0 if not yet loaded.
*/
unsigned int
size(void)
{
return size_y;
}
/*
* Unloads dictionary from memory. Returns true if successful else false.
*/
bool unload(void)
{
//TODO
//700 is the size of my hash table...
 for(int i=0;i<700;i++)
   {
BUCKET * temm=NULL;
BUCKET * temmp;
temm=buckets[i];
     while(temm!=NULL)
       {
   temmp=temm;
       temm=temm->next;    
         free(temmp);
       }
   }  
return true;
}

int hash_f(const char *key)
     {
//my hash function groups words using thier 1st and second letter only...
          int lent=strlen(key);
              if(lent==1)
                  {
              int first,check,final;
              first=key[0]-'a';
              check=first*27;
              final=check;
                  return final;
                  }
 //else if more than one letter..
              else
                 {
              int first,second,check,final;
                first=key[0]-'a';
                second=key[1]-'a';
                check=first*27;
                final=check+first+second;    
                   return final;
                  }
      
  } 

